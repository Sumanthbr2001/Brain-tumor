import warnings
warnings.filterwarnings('ignore')
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Including & Reading the CSV file:
df = pd.read_csv("data.csv")
df.head()
df.columns
df.info()
#df = df.drop("Unnamed: 32", axis=1)

# to check whether those values are
# deletd or not:
df.head()

# also check the columns after this
# process:
df.columns

df.drop('id', axis=1, inplace=True)
# we can do this also: df = df.drop('id', axis=1)

# To see the change, again go through
# the columns
df.columns

l = list(df.columns)
print(l)
features_mean = l[1:11]

features_se = l[11:21]

features_worst = l[21:]
df.head (2)
df['diagnosis'].unique()
#sns.countplot(df['diagnosis'], label="Count",);
df.shape

corr = df.corr()
corr
plt.figure(figsize=(14, 14))
sns.heatmap(corr)

df.head()
df['diagnosis'] = df['diagnosis'].map({'M': 1, 'B': 0})
df.head()

df['diagnosis'].unique()

X = df.drop('diagnosis', axis=1)
X.head()

y = df['diagnosis']
y.head()
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3)

df.shape
# o/p: (569, 31)

X_train.shape
# o/p: (398, 30)

X_test.shape
# o/p: (171, 30)

y_train.shape
# o/p: (398,)

y_test.shape
# o/p: (171,)

X_train.head(1)
# will return the top 5 rows (if exists)

ss = StandardScaler()
X_train = ss.fit_transform(X_train)
X_test = ss.transform(X_test)

X_train
from sklearn.linear_model import LogisticRegression

lr = LogisticRegression()
lr.fit(X_train, y_train)

# implemented our model through logistic regression
y_pred = lr.predict(X_test)
y_pred

# array containing the actual output
y_test
from sklearn.metrics import accuracy_score
lr_acc=accuracy_score(y_test, y_pred)
print("Logistic Regression :",accuracy_score(y_test, y_pred))
results=accuracy_score(y_test, y_pred)
tempResults = pd.DataFrame({'Algorithm':['Logistic Regression Method'], 'Accuracy':[lr_acc]})


from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier

dtc = DecisionTreeClassifier()
dtc.fit(X_train, y_train)

y_pred = dtc.predict(X_test)
y_pred
dtc_acc=accuracy_score(y_test, y_pred)
print("Decision Tree :",accuracy_score(y_test, y_pred))

# Tabulating the results
tempResults = pd.DataFrame({'Algorithm': ['Decision tree Classifier Method'],
                            'Accuracy': [dtc_acc]})

from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier

rfc = RandomForestClassifier()
rfc.fit(X_train, y_train)

y_pred = rfc.predict(X_test)
y_pred

print("Random Forest:",accuracy_score(y_test, y_pred))
from sklearn import svm

svc = svm.SVC()
svc.fit(X_train, y_train)

y_pred = svc.predict(X_test)
y_pred

from sklearn.metrics import accuracy_score

print("SVM:",accuracy_score(y_test, y_pred))
plt.show()
