
from turtledemo.chaos import plot

import matplotlib.pyplot as plt  # data visualization
import numpy as np  # linear algebra
import pandas as pd  # data processing, CSV file I/O (e.g. pd.read_csv)
# init_notebook_mode(connected=True)
import plotly.graph_objs as go
import seaborn as sns  # statistical data visualization

from plotly.offline import iplot


data = pd.read_csv('data.csv')


data.isnull().sum() #shows how many of the null
print("===================================")
print("Pre-process data")
print("===================================")
print(data.isnull().sum())
from sklearn import preprocessing

scale_v = data[['id']]
scale_b = data[['radius_mean']]

minmax_scaler = preprocessing.MinMaxScaler()

v_scaled = minmax_scaler.fit_transform(scale_v)
b_scaled = minmax_scaler.fit_transform(scale_b)

data['v_ScaledUp'] = pd.DataFrame(v_scaled)
data['b_ScaledUp'] = pd.DataFrame(b_scaled)

print(data)
