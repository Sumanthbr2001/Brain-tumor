from tkinter import *
from tkinter import messagebox


from PIL import ImageTk, Image
import sqlite3
import os
root = Tk()
root.geometry('1366x768')
root.title("BrainTumor")

canv = Canvas(root, width=1366, height=768, bg='white')
canv.grid(row=2, column=3)
img = Image.open('back.png')
photo = ImageTk.PhotoImage(img)
canv.create_image(1,1, anchor=NW, image=photo)
def readimg():
    os.system('python Tumormain.py')
def rdata():
    os.system('python loaddataset.py')
def pre():
    os.system('python preprocess.py')
def clf():
        os.system('python ML1.py')
Button(root, text='Detect Brain Tumour', width=23, bg='yellow', fg='black',  font=("bold", 10),command=readimg).place(x=100, y=350)
Button(root, text='Read Dataset', width=23, bg='yellow', fg='black',  font=("bold", 10),command=rdata).place(x=100, y=200)
Button(root, text='Preprocessing', width=23, bg='yellow', fg='black',  font=("bold", 10),command=pre).place(x=100, y=250)
Button(root, text='Classification', width=23, bg='yellow', fg='black',  font=("bold", 10),command=clf).place(x=100, y=300)
root.mainloop()
